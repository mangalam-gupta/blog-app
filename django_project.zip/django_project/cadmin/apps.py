from django.apps import AppConfig


class CadminConfig(AppConfig):
    name = 'cadmin'
